# API de Transações

API REST desenvolvida com FastAPI para gerenciamento de transações financeiras.

## Como rodar

```bash
python -m venv venv
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
venv\Scripts\activate
pip install -r requirements.txt
python -m uvicorn app.main:app --reload


Acessa:
http://127.0.0.1:8000/docs