from fastapi import FastAPI
from app.routes.transaction import router as transaction_router

app = FastAPI(title="Fraud Transactions API")

app.include_router(transaction_router)