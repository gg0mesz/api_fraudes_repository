# Setup do Banco de Dados (MySQL)

## 1. Criar banco

```sql
CREATE DATABASE IF NOT EXISTS bancodobrasil;
USE bancodobrasil;

2. Criar tabela
CREATE TABLE IF NOT EXISTS transacoes (
    id INT PRIMARY KEY,
    valor FLOAT,
    data DATE,
    hora TIME,
    dia_semana VARCHAR(20),
    categoria VARCHAR(50),
    conta VARCHAR(20),
    cidade VARCHAR(50),
    estado VARCHAR(10),
    pais VARCHAR(50),
    latitude FLOAT,
    longitude FLOAT,
    tipo_transacao VARCHAR(50),
    dispositivo VARCHAR(50),
    estabelecimento VARCHAR(100),
    tentativas INT,
    ip_origem VARCHAR(50),
    is_fraude INT
);

3. Verificar dados
USE bancodobrasil;
SELECT * FROM transacoes LIMIT 10;
4. Importar dados via Python

Rodar:

python importar_json_mysql.py


Observações
Banco: bancodobrasil
Tabela: transacoes
Usuário: bancodobrasil
Senha: 12345